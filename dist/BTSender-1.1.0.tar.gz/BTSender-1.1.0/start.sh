#!/bin/sh -x

export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/usr/local/lib

python BTSender.py
