#!/usr/bin/env python

#
#  BTSender by Arve and Sander ( Bluetooth Sender )
#  Copyright (C) 2006  Arve Barsnes and Sander Johansen
#
#  This program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; either version 2 of the License, or
#  (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software
#  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#
#  Sander Johansen <sanderj@ifi.uio.no>
#  Arve Barsnes <arveba@ifi.uio.no>
#

import time
import os
import pythonussp

# seconds of time between a file is finished and a new file is sent, 
# some delay caused when scanning after devices
time_between_files = 5

# send file to remote device (1), or just pretend doing it (0)
actually_send_files = 1

# print log messages?
log_out = 1

class Files:
  """The class for keeping info about files to send to devices."""

  def __init__(self):
    global files_available, log_out
    files_available = self
    self.file = 0
    self.log_out= log_out

  def append(self, filename, filepath):
    f= File(filename,filepath)
    if self.log_out != 0:
      print "Added file:", filename

    if self.file == 0:
      self.file = f
    else:
      current = self.file
      while current.next != 0:
        current = current.next
      current.next = f

class Devices:
  """The class for keeping the info about the devices."""
  def __init__(self):
    global log_out, actually_send_files
    self.dev = 0
    self.count = 0
    self.online = ()
    self.log_out= log_out
    self.actually_send_files= actually_send_files

  def log(self,b,msg):
    if self.log_out != 0:
      print b.address, ":", msg

  def is_connecting(self,b):
    """Current device is connecting."""
    self.log(b,"Connecting")
    self.try_sending(b)

  def is_online(self,b):
    """Current device is still online."""
    self.try_sending(b)
    #self.log(b,"Online: " + str(time.time() - b.connected_time) + "s")   

  def is_disconnecting(self,b):
    """Current device is disconnecting."""
    self.log(b,"Disconnecting")
    
  def is_sending(self,b):
    """Is supposed to send a file to current device."""
    global time_between_files
    if b.last_sent == 0:
      last_sent = 0
    else:
      last_sent = time.time() - b.last_sent

    self.log(b,"Sending file " + b.files[0].filename)
    if self.actually_send_files == 1:
      pythonussp.ussp_call(b.address + '@', b.files[0].filepath, b.files[0].filename, 60)
    
    b.is_sending= 1

  def is_finished_sending(self,b):
    """Current device is finished reciving a file."""
    b.last_sent = time.time()
    b.is_sending = 0
    self.log(b,"Transfer finished")

  def try_sending(self,b):
    """Send a file when the time is right."""
    global time_between_files

    # someone comes online after reciving a file
    if b.is_sending == 1:
      self.is_finished_sending(b)

    if (b.last_sent + time_between_files) < time.time() and b.last_sent != -1:
      if len(b.files) > 0:
        self.is_sending(b)
        del b.files[0]
      else:
        self.log(b,"No more files to send")
        b.last_sent = -1

  def __iadd__(self, addr):
    """Add a new device, if it already is added set it to online."""

    b = self[addr]
    if b != 0:
      self.set_online(b.address)
      self.is_online(b)
    else:
      b = Device(addr)
      if self.count == 0:
        self.dev = b
        self.count = 1
      else:
        current = self.dev
        while current.next != 0:
          current = current.next
        current.next = b
        self.count += 1
      self.is_connecting(b)
    return self

  def reset(self):
    """Set all devices to off."""
    if self.count == 0:
      return
    current = self.dev
    while current != 0:

      # make sure someone who is reciving a file isn't listed
      # as offline, even if the device is offline
      if current.is_sending == 0:
        current.online = 0
      current = current.next

  def prune(self):
    """Delete all devices set to off now."""

    # update the first pointer if elements first is deleted
    while self.count != 0 and self.dev.online == 0:
      self.is_disconnecting(self.dev)
      self.dev = self.dev.next
      self.count -= 1

    current = self.dev
    if current != 0:
      # delete all other devices set to off
      while current.next != 0:
        if current.next.online == 0:
          self.is_disconnecting(current.next)
          current.next = current.next.next
          self.count -= 1
        else:
          current = current.next

  def __getitem__(self, i):
    """Return device with address i if it exists."""
    if self.count == 0:
      return 0
    current = self.dev
    while current != 0:
      if current.address == i:
        return current
      current= current.next
    return 0

  def set_online(self,addr):
    """Set a device to online."""
    current = self.dev
    while current != 0:
      if current.address == addr:
        current.online = 1
        return
      current = current.next


class Device:
  """The class for info about a specific device."""

  def __init__(self, address):
    self.address = address
    self.next = 0
    self.online = 1
    self.last_sent = 0
    self.connected_time = time.time()
    self.is_sending = 0

    self.files= []               # should be updated with pointers to files not sent
    global files_available
    current = files_available.file
    while current != 0:
      self.files.append(current)
      current = current.next

class File:
  """The class for info about a specific file."""
  def __init__(self, filename, filepath):
    self.filename = filename
    self.filepath = filepath
    self.next = 0

